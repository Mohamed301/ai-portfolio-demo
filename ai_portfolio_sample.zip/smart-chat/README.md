# Smart-Chat — نظام دردشة ذكي مخصص للشركات

نظام دردشة مخصص للشركات يعتمد على LLMs وRAG لعرض إجابات سياقية من مستندات داخلية.
ملفات:
- streamlit_app.py: تطبيق Streamlit تجريبي لواجهة الدردشة.
- README.md: وصف المشروع وتعليمات التشغيل.


## كيفية التشغيل (محليًا)

1. إنشاء بيئة افتراضية
```bash
python -m venv venv
source venv/bin/activate  # on Windows use venv\Scripts\activate
pip install -r requirements.txt
```

2. تشغيل التطبيق التجريبي
```bash
# Streamlit
streamlit run streamlit_app.py
# أو FastAPI
uvicorn app:app --reload --port 8000
```

## ملاحظات
- هذا مشروع تجريبي صالح للعرض في معرض الأعمال. يمكنك استبدال الكود بمشروعك الحقيقي أو توسيعه.
