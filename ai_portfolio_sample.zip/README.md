# AI-Portfolio-Samples

هذا أرشيف يحتوي على ثلاثة مشاريع تجريبية جاهزة للعرض على GitHub.  
استخدم هذه الملفات كنقطة انطلاق: استبدل الأكواد بالنسخ الفعلية من مشاريعك، وأرفق لقطات شاشة حقيقية أو روابط مباشرة لتطبيقات مُستضافة.

## كيفية رفعه إلى GitHub
```bash
git init
git add .
git commit -m "Initial demo portfolio"
git branch -M main
# أنشئ الريبو في GitHub ثم:
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```

## مقترحات للنشر
- لتحويل أحد المشاريع إلى عرض مباشر سريع: استخدم Hugging Face Spaces (Streamlit)، أو GitHub Pages، أو نشر تطبيق FastAPI على Railway/Render.
