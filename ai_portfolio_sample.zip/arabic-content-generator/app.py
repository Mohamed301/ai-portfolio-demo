from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Query(BaseModel):
    prompt: str

@app.post("/generate")
async def generate(q: Query):
    # محاكاة ناتج التوليد
    return {"input": q.prompt, "output": "هذا نص تجريبي مُولّد بالعربية لعرض نموذج المخرجات."}
