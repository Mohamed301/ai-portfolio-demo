# Arabic-Content-Generator — مولّد محتوى عربي باستخدام GPT

أداة تجريبية لتوليد نص عربي (مُحاكاة). واجهة بسيطة مع أمثلة مدخلة ومخرجات.
ملفات:
- app.py: FastAPI تجريبي مع مثال للناتج.
- README.md


## كيفية التشغيل (محليًا)

1. إنشاء بيئة افتراضية
```bash
python -m venv venv
source venv/bin/activate  # on Windows use venv\Scripts\activate
pip install -r requirements.txt
```

2. تشغيل التطبيق التجريبي
```bash
# Streamlit
streamlit run streamlit_app.py
# أو FastAPI
uvicorn app:app --reload --port 8000
```

## ملاحظات
- هذا مشروع تجريبي صالح للعرض في معرض الأعمال. يمكنك استبدال الكود بمشروعك الحقيقي أو توسيعه.
